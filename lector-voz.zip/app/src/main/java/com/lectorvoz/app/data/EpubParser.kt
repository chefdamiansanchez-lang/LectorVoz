package com.lectorvoz.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.jsoup.Jsoup
import java.io.BufferedInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

data class EpubMetadata(val title: String?, val cover: Bitmap?)

object EpubParser {

    /** Un EPUB es un .zip; lo recorremos secuencialmente con ZipInputStream
     *  porque Android no siempre permite acceso random-access sobre un
     *  Uri de SAF (no hay File real detrás). */
    private fun <T> readZip(context: Context, uri: Uri, block: (ZipInputStream) -> T): T {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir el EPUB" }
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                return block(zip)
            }
        }
    }

    fun readMetadata(context: Context, uri: Uri): EpubMetadata {
        return try {
            var opfPath: String? = null
            var opfBytes: ByteArray? = null
            var coverPath: String? = null
            var coverBytes: ByteArray? = null

            // Primera pasada: container.xml -> ruta del OPF, y leemos el OPF.
            readZip(context, uri) { zip ->
                var entry: ZipEntry?
                while (zip.nextEntry.also { entry = it } != null) {
                    val name = entry!!.name
                    when {
                        name.equals("META-INF/container.xml", ignoreCase = true) -> {
                            val xml = zip.readBytes().toString(Charsets.UTF_8)
                            opfPath = Regex("full-path=\"([^\"]+)\"").find(xml)?.groupValues?.get(1)
                        }
                        opfPath != null && name.equals(opfPath, ignoreCase = true) -> {
                            opfBytes = zip.readBytes()
                        }
                    }
                }
            }

            val opfText = opfBytes?.toString(Charsets.UTF_8)
            val title = opfText?.let {
                Regex("<dc:title[^>]*>([^<]*)</dc:title>").find(it)?.groupValues?.get(1)?.trim()
            }

            // Buscamos el id de la imagen de portada en el manifest/metadata del OPF.
            if (opfText != null) {
                val coverMetaId = Regex("name=\"cover\"[^/]*content=\"([^\"]+)\"").find(opfText)
                    ?.groupValues?.get(1)
                val manifestItems = Regex(
                    "<item[^>]*id=\"([^\"]+)\"[^>]*href=\"([^\"]+)\"[^>]*/?>"
                ).findAll(opfText)
                val idToHref = manifestItems.associate { it.groupValues[1] to it.groupValues[2] }
                val href = coverMetaId?.let { idToHref[it] }
                    ?: idToHref.entries.firstOrNull { it.key.contains("cover", true) }?.value

                if (href != null) {
                    val opfDir = opfPath?.substringBeforeLast('/', "") ?: ""
                    coverPath = if (opfDir.isEmpty()) href else "$opfDir/$href"
                }
            }

            if (coverPath != null) {
                readZip(context, uri) { zip ->
                    var entry: ZipEntry?
                    while (zip.nextEntry.also { entry = it } != null) {
                        if (entry!!.name.equals(coverPath, ignoreCase = true)) {
                            coverBytes = zip.readBytes()
                        }
                    }
                }
            }

            val cover = coverBytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            EpubMetadata(title, cover)
        } catch (e: Exception) {
            EpubMetadata(null, null)
        }
    }

    fun extractText(context: Context, uri: Uri): BookContent {
        val paragraphs = mutableListOf<String>()
        try {
            var opfPath: String? = null
            var opfBytes: ByteArray? = null
            val htmlByName = mutableMapOf<String, ByteArray>()

            readZip(context, uri) { zip ->
                var entry: ZipEntry?
                while (zip.nextEntry.also { entry = it } != null) {
                    val name = entry!!.name
                    val lower = name.lowercase()
                    when {
                        lower == "meta-inf/container.xml" -> {
                            val xml = zip.readBytes().toString(Charsets.UTF_8)
                            opfPath = Regex("full-path=\"([^\"]+)\"").find(xml)?.groupValues?.get(1)
                        }
                        lower.endsWith(".xhtml") || lower.endsWith(".html") || lower.endsWith(".htm") -> {
                            htmlByName[name] = zip.readBytes()
                        }
                        opfPath != null && name.equals(opfPath, ignoreCase = true) -> {
                            opfBytes = zip.readBytes()
                        }
                    }
                }
            }
            // Nota: como opf_path se conoce recién durante el recorrido, en
            // algunos EPUB el OPF puede procesarse en un segundo pase si el
            // container.xml aparece después del OPF en el zip (raro, pero
            // por robustez repetimos la lectura si falta).
            if (opfBytes == null) {
                readZip(context, uri) { zip ->
                    var entry: ZipEntry?
                    while (zip.nextEntry.also { entry = it } != null) {
                        if (opfPath != null && entry!!.name.equals(opfPath, ignoreCase = true)) {
                            opfBytes = zip.readBytes()
                        }
                    }
                }
            }

            val opfText = opfBytes?.toString(Charsets.UTF_8)
            val orderedHrefs = mutableListOf<String>()
            if (opfText != null) {
                val manifestItems = Regex(
                    "<item[^>]*id=\"([^\"]+)\"[^>]*href=\"([^\"]+)\"[^>]*/?>"
                ).findAll(opfText).associate { it.groupValues[1] to it.groupValues[2] }
                val spineIds = Regex("<itemref[^>]*idref=\"([^\"]+)\"").findAll(opfText)
                    .map { it.groupValues[1] }.toList()
                val opfDir = opfPath?.substringBeforeLast('/', "") ?: ""
                for (id in spineIds) {
                    val href = manifestItems[id] ?: continue
                    orderedHrefs.add(if (opfDir.isEmpty()) href else "$opfDir/$href")
                }
            }

            val filesInOrder = if (orderedHrefs.isNotEmpty()) {
                orderedHrefs.mapNotNull { href ->
                    htmlByName.entries.firstOrNull { it.key.equals(href, ignoreCase = true) }?.value
                }
            } else {
                htmlByName.values.toList()
            }

            for (bytes in filesInOrder) {
                val html = bytes.toString(Charsets.UTF_8)
                val text = Jsoup.parse(html).body().text()
                if (text.isNotBlank()) {
                    // Dividimos en oraciones/párrafos razonables para el TTS.
                    text.split(Regex("(?<=[.!?])\\s+")).forEach { s ->
                        if (s.isNotBlank()) paragraphs.add(s.trim())
                    }
                }
            }
        } catch (e: Exception) {
            paragraphs.add("No se pudo leer el contenido de este libro.")
        }
        return BookContent(paragraphs)
    }
}
