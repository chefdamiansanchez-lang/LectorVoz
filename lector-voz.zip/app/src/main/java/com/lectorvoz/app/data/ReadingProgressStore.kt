package com.lectorvoz.app.data

import android.content.Context

class ReadingProgressStore(context: Context) {
    private val prefs = context.getSharedPreferences("lector_progreso", Context.MODE_PRIVATE)

    fun getProgress(bookId: String): Int = prefs.getInt(bookId, 0)

    fun saveProgress(bookId: String, paragraphIndex: Int) {
        prefs.edit().putInt(bookId, paragraphIndex).apply()
    }
}
