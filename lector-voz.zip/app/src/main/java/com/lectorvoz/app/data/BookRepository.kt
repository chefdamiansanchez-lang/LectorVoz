package com.lectorvoz.app.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Detección de libros vía Storage Access Framework (SAF).
 *
 * En Android 11+ el almacenamiento con ámbito (scoped storage) impide leer
 * archivos arbitrarios del dispositivo por ruta directa, y MediaStore solo
 * indexa fotos/video/audio, no EPUB ni PDF. Por eso la versión anterior no
 * encontraba los libros. La forma confiable es: el usuario elige UNA VEZ una
 * carpeta con ACTION_OPEN_DOCUMENT_TREE, persistimos el permiso sobre esa
 * carpeta, y a partir de ahí recorremos su árbol con DocumentFile.
 */
class BookRepository(private val context: Context) {

    fun persistFolderPermission(treeUri: Uri) {
        val takeFlags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
        context.getSharedPreferences("lector_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("carpeta_libros", treeUri.toString())
            .apply()
    }

    fun getSavedFolderUri(): Uri? {
        val saved = context.getSharedPreferences("lector_prefs", Context.MODE_PRIVATE)
            .getString("carpeta_libros", null) ?: return null
        return Uri.parse(saved)
    }

    suspend fun scanBooks(): List<Book> = withContext(Dispatchers.IO) {
        val treeUri = getSavedFolderUri() ?: return@withContext emptyList()
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        val found = mutableListOf<Book>()
        scanRecursive(root, found)
        found
    }

    private fun scanRecursive(dir: DocumentFile, out: MutableList<Book>) {
        val children = dir.listFiles()
        for (file in children) {
            if (file.isDirectory) {
                scanRecursive(file, out)
                continue
            }
            val name = file.name ?: continue
            val lower = name.lowercase()
            when {
                lower.endsWith(".epub") -> {
                    val meta = EpubParser.readMetadata(context, file.uri)
                    out.add(
                        Book(
                            id = file.uri.toString(),
                            uri = file.uri,
                            title = meta.title ?: name.removeSuffix(".epub"),
                            format = BookFormat.EPUB,
                            cover = meta.cover
                        )
                    )
                }
                lower.endsWith(".pdf") -> {
                    val cover = PdfParser.renderCover(context, file.uri)
                    out.add(
                        Book(
                            id = file.uri.toString(),
                            uri = file.uri,
                            title = name.removeSuffix(".pdf"),
                            format = BookFormat.PDF,
                            cover = cover
                        )
                    )
                }
            }
        }
    }

    suspend fun loadContent(book: Book): BookContent = withContext(Dispatchers.IO) {
        when (book.format) {
            BookFormat.EPUB -> EpubParser.extractText(context, book.uri)
            BookFormat.PDF -> PdfParser.extractText(context, book.uri)
        }
    }
}
