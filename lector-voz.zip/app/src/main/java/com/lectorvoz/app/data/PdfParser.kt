package com.lectorvoz.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer
import com.tom_roush.pdfbox.text.PDFTextStripper

object PdfParser {

    private fun ensureInit(context: Context) {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    fun renderCover(context: Context, uri: Uri): Bitmap? {
        return try {
            ensureInit(context)
            context.contentResolver.openInputStream(uri).use { input ->
                PDDocument.load(input).use { doc ->
                    val renderer = PDFRenderer(doc)
                    renderer.renderImage(0, 1.0f)
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    fun extractText(context: Context, uri: Uri): BookContent {
        return try {
            ensureInit(context)
            val fullText = context.contentResolver.openInputStream(uri).use { input ->
                PDDocument.load(input).use { doc ->
                    PDFTextStripper().getText(doc)
                }
            }
            val paragraphs = fullText
                .split(Regex("(?<=[.!?])\\s+|\\n{2,}"))
                .map { it.trim() }
                .filter { it.isNotBlank() }
            BookContent(paragraphs)
        } catch (e: Exception) {
            BookContent(listOf("No se pudo leer el contenido de este PDF."))
        }
    }
}
