package com.lectorvoz.app.data

import android.graphics.Bitmap
import android.net.Uri

enum class BookFormat { EPUB, PDF }

data class Book(
    val id: String,        // usamos el URI del documento como id estable
    val uri: Uri,
    val title: String,
    val format: BookFormat,
    val cover: Bitmap? = null
)

data class BookContent(
    val paragraphs: List<String>
)
