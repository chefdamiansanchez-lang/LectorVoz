package com.lectorvoz.app.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat.MediaStyle
import androidx.media.session.MediaButtonReceiver
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import com.lectorvoz.app.MainActivity
import com.lectorvoz.app.R
import java.util.Locale
import java.util.UUID

class TtsReaderService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "lectura_en_curso"
        const val NOTIF_ID = 1

        const val ACTION_START = "com.lectorvoz.app.action.START"
        const val ACTION_PLAY = "com.lectorvoz.app.action.PLAY"
        const val ACTION_PAUSE = "com.lectorvoz.app.action.PAUSE"
        const val ACTION_STOP = "com.lectorvoz.app.action.STOP"
        const val ACTION_SET_SPEED = "com.lectorvoz.app.action.SET_SPEED"

        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_PARAGRAPHS = "extra_paragraphs"
        const val EXTRA_START_INDEX = "extra_start_index"
        const val EXTRA_SPEED = "extra_speed"

        // Estado observable simple para que la UI se sincronice con el servicio.
        var currentIndex = 0
        var totalParagraphs = 0
        var isSpeaking = false
        var onProgress: ((Int, Int, Boolean) -> Unit)? = null
        var onBookTitle: ((String) -> Unit)? = null
    }

    private lateinit var tts: TextToSpeech
    private lateinit var mediaSession: MediaSessionCompat
    private var paragraphs: List<String> = emptyList()
    private var title: String = ""
    private var speechRate: Float = 1.0f
    private var ttsReady = false
    private var pendingAutoplay = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
        mediaSession = MediaSessionCompat(this, "LectorVozSession").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { resumeReading() }
                override fun onPause() { pauseReading() }
                override fun onStop() { stopReading() }
            })
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                title = intent.getStringExtra(EXTRA_TITLE) ?: "Libro"
                paragraphs = intent.getStringArrayListExtra(EXTRA_PARAGRAPHS) ?: emptyList()
                currentIndex = intent.getIntExtra(EXTRA_START_INDEX, 0).coerceIn(0, (paragraphs.size - 1).coerceAtLeast(0))
                totalParagraphs = paragraphs.size
                speechRate = intent.getFloatExtra(EXTRA_SPEED, 1.0f)
                onBookTitle?.invoke(title)
                startForeground(NOTIF_ID, buildNotification())
                if (ttsReady) startSpeakingFromCurrent() else pendingAutoplay = true
            }
            ACTION_PLAY -> resumeReading()
            ACTION_PAUSE -> pauseReading()
            ACTION_STOP -> stopReading()
            ACTION_SET_SPEED -> {
                speechRate = intent.getFloatExtra(EXTRA_SPEED, 1.0f)
                tts.setSpeechRate(speechRate)
            }
        }
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Requisito: el motor de lectura debe funcionar estrictamente en español.
            val result = tts.setLanguage(Locale("spa", "ESP"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale("es", "ES"))
            }
            tts.setSpeechRate(speechRate)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    isSpeaking = true
                    notifyProgress()
                }
                override fun onDone(utteranceId: String?) {
                    currentIndex++
                    if (currentIndex < paragraphs.size) {
                        speakParagraph(currentIndex)
                    } else {
                        isSpeaking = false
                        notifyProgress()
                        stopSelf()
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    notifyProgress()
                }
            })
            ttsReady = true
            if (pendingAutoplay) {
                pendingAutoplay = false
                startSpeakingFromCurrent()
            }
        }
    }

    private fun startSpeakingFromCurrent() {
        if (paragraphs.isEmpty()) return
        speakParagraph(currentIndex)
    }

    private fun speakParagraph(index: Int) {
        if (index !in paragraphs.indices) return
        val id = UUID.randomUUID().toString()
        tts.speak(paragraphs[index], TextToSpeech.QUEUE_FLUSH, null, id)
        updatePlaybackState(PlaybackStateCompat.STATE_PLAYING)
        updateNotification()
    }

    private fun resumeReading() {
        if (!ttsReady) { pendingAutoplay = true; return }
        speakParagraph(currentIndex)
    }

    private fun pauseReading() {
        tts.stop()
        isSpeaking = false
        updatePlaybackState(PlaybackStateCompat.STATE_PAUSED)
        notifyProgress()
        updateNotification()
    }

    private fun stopReading() {
        tts.stop()
        isSpeaking = false
        updatePlaybackState(PlaybackStateCompat.STATE_STOPPED)
        notifyProgress()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyProgress() {
        onProgress?.invoke(currentIndex, totalParagraphs, isSpeaking)
    }

    private fun updatePlaybackState(state: Int) {
        val actions = PlaybackStateCompat.ACTION_PLAY or
                PlaybackStateCompat.ACTION_PAUSE or
                PlaybackStateCompat.ACTION_STOP
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, currentIndex.toLong(), speechRate)
                .build()
        )
        mediaSession.isActive = state == PlaybackStateCompat.STATE_PLAYING
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Lectura en curso", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val playPauseAction = if (isSpeaking) {
            NotificationCompat.Action(
                android.R.drawable.ic_media_pause, "Pausar",
                MediaButtonReceiver.buildMediaButtonPendingIntent(this, PlaybackStateCompat.ACTION_PAUSE)
            )
        } else {
            NotificationCompat.Action(
                android.R.drawable.ic_media_play, "Reproducir",
                MediaButtonReceiver.buildMediaButtonPendingIntent(this, PlaybackStateCompat.ACTION_PLAY)
            )
        }
        val stopAction = NotificationCompat.Action(
            android.R.drawable.ic_media_stop, "Detener",
            MediaButtonReceiver.buildMediaButtonPendingIntent(this, PlaybackStateCompat.ACTION_STOP)
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText("Leyendo en voz alta • párrafo ${currentIndex + 1} de $totalParagraphs")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openAppIntent)
            .addAction(playPauseAction)
            .addAction(stopAction)
            .setStyle(
                MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(0, 1)
            )
            .setOngoing(isSpeaking)
            .build()
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification())
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        mediaSession.release()
        super.onDestroy()
    }
}
